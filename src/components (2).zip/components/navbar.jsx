import { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import logoImg from '../assets/img/Dentis_Tree_Namee.png';
import logo from '../assets/img/Dentis_Tree_logoo.png';
import logoo from '../assets/img/Dentis_Tree_logooo.png';

import Topbar from './Topbar'; 
import Gallerypage from "./Gallerypage";
const Navbar = ({ isSticky, formRef }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navClass = isSticky 
    ? 'navbar navbar-expand-lg navbar-light fixed-top' 
    : 'navbar navbar-expand-lg navbar-light';

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  return (
    <>
      {!isSticky && <Topbar />}

      <nav className={navClass}
        style={{
          position: isSticky ? 'fixed' : 'relative',
          top: 0,
          zIndex: 1000,
          width: '100%',
          transition: 'all 0.3s ease',
          backgroundColor: 'white',
          boxShadow: isSticky ? '0 2px 10px rgba(0,0,0,0.1)' : 'none',
          padding: '10px 0'
        }}>
        <div className="container-fluid px-lg-5 d-flex align-items-center justify-content-between">
          
          {/* Logo Section */}
          <div className="navbar-brand d-flex align-items-center m-0">
            <Link to="/" className="d-flex align-items-center text-decoration-none" onClick={closeMenu}>
              <img 
                alt="Logo" 
                src={logoo} 
                style={{ 
                  width: '120px', 
                  height: 'auto',
                  transition: '0.3s' 
                }} 
              />
              <img 
                alt="Logo Name" 
                src={logoImg} 
                className="d-none d-sm-block ms-2" 
                style={{ 
                  width: '180px', 
                  height: 'auto',
                  marginTop: '5px'
                }} 
              />
            </Link>
          </div>

          {/* Toggle Button (Hamburger) */}
          <button 
            className="navbar-toggler" 
            type="button" 
            onClick={toggleMenu}
            aria-label="Toggle navigation"
            style={{ padding: '6px 10px', fontSize: '1.25rem', border: '1px solid #ddd' }}
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          {/* Responsive Navigation Menu */}
          <div className={`collapse navbar-collapse ${isOpen ? 'show' : ''}`} id="navbarTogglerMenu">
            
            <div className="ms-auto w-100 d-lg-flex align-items-center justify-content-end backend-nav-wrapper">
              
              <ul className="navbar-nav mb-2 mb-lg-0 me-lg-4 gap-1 gap-lg-0 custom-nav-list">
                <li className="nav-item">
                  <Link to="/" className="nav-link fw-semibold px-lg-3 custom-link-item" onClick={closeMenu}>
                    <span>Home</span> <i className="bi bi-chevron-right d-lg-none"></i>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/about" className="nav-link fw-semibold px-lg-3 custom-link-item" onClick={closeMenu}>
                    <span>About Us</span> <i className="bi bi-chevron-right d-lg-none"></i>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/gallery" className="nav-link fw-semibold px-lg-3 custom-link-item" onClick={closeMenu}>
                    <span>Gallery</span> <i className="bi bi-chevron-right d-lg-none"></i>
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/contact" className="nav-link fw-semibold px-lg-3 custom-link-item" onClick={closeMenu}>
                    <span>Contact Us</span> <i className="bi bi-chevron-right d-lg-none"></i>
                  </Link>
                </li>
              </ul>

              {/* Appointment Button */}
              <div className="nav-item pt-3 pt-lg-0 custom-btn-wrapper">
                <button 
                  className="btn-modern-appointment w-100 w-lg-auto" 
                  style={{ padding: '12px 24px', borderRadius: '30px', whiteSpace: 'nowrap', fontWeight: '600' }}
                  onClick={() => {
                    formRef.current.scrollIntoView({ behavior: "smooth" });
                    closeMenu();
                  }}
                >
                  Book Appointment
                </button>
              </div>

            </div>

          </div>

        </div>
      </nav>

      {/* Styled css to overwrite white text issue and enhance UI */}
      <style>{`
        @media (max-width: 991.98px) {
          .collapse.navbar-collapse {
            display: none;
          }
          .collapse.navbar-collapse.show {
            display: block !important;
            background-color: #ffffff !important;
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            padding: 24px !important;
            box-shadow: 0 15px 25px rgba(0,0,0,0.1);
            border-top: 1px solid #f0f0f0;
            z-index: 999;
          }
          .custom-nav-list {
            flex-direction: column !important;
            align-items: flex-start !important;
            margin-bottom: 5px !important;
            width: 100%;
          }
          .custom-nav-list .nav-item {
            width: 100%;
          }
          /* This forcefully overrides the theme's white color conflict */
          .custom-link-item, 
          .navbar-light .navbar-nav .nav-link.custom-link-item {
            color: #1a2530 !important; 
            font-size: 1.05rem !important;
            font-weight: 600 !important;
            padding: 14px 10px !important;
            width: 100% !important;
            border-bottom: 1px solid #f3f4f6;
            display: flex !important;
            justify-content: space-between;
            align-items: center;
            text-decoration: none;
            transition: all 0.2s ease;
          }
          .custom-link-item:hover {
            background-color: #f8fafc;
            color: #0d6efd !important;
            padding-left: 15px !important;
          }
          .custom-link-item i {
            font-size: 0.85rem;
            color: #9ca3af;
          }
          .custom-btn-wrapper {
            width: 100%;
            padding-top: 15px;
          }
        }
      `}</style>
    </>
  );
};

export default Navbar;

// import { useRef } from 'react';
// import AppointmentForm from './AppointmentForm';
// import { Fragment } from 'react';
// import { Link } from 'react-router-dom';
// import logoImg from '../assets/img/Dentis_Tree_Namee.png';
// import logo from '../assets/img/Dentis_Tree_logoo.png';
// import 'bootstrap/dist/js/bootstrap.bundle.min.js'; // <-- Yeh line add karein
// import Topbar from './Topbar'; // 1. Topbar ko yahan import kiya

// const Navbar = ({ isSticky, formRef }) => {
//   const services = [
//     { id: 1, title: 'Dental Checkup' },
//     { id: 2, title: 'Teeth Whitening' }
//   ];

//   const navClass = isSticky 
//     ? 'navbar navbar-expand-lg center-nav transparent navbar-light navbar-clone fixed' 
//     : 'navbar navbar-expand-lg center-nav transparent navbar-light';

//   return (
//     <>
//       {/* 2. Navbar ke upar Topbar add kiya (Yahi agar sticky ho to chhup bhi sakta hai) */}
//       {!isSticky && <Topbar />}

//       <nav className={navClass}
//         style={{
//           position: 'sticky',
//           top: 0,
//           zIndex: 1000,
//           width: '100%',
//           transition: 'all 0.3s ease',
//           backgroundColor: 'white',
//           boxShadow: isSticky ? '0 2px 10px rgba(0,0,0,0.1)' : 'none',
//         }}>
//         <div className="container-fluid px-lg-5 flex-lg-row flex-nowrap align-items-center">
          
//           <div className="navbar-brand d-flex align-items-center ms-lg-0" style={{ marginLeft: '-15px' }}>
//             <Link to="/" className="d-flex align-items-center text-decoration-none">
//               <img 
//                 alt="Logo" 
//                 src={logo} 
//                 style={{ 
//                   width: '90px', 
//                   height: 'auto',
//                   transition: '0.3s' 
//                 }} 
//               />
//               <img 
//                 alt="Logo Name" 
//                 src={logoImg} 
//                 className="d-none d-sm-block" 
//                 style={{ 
//                   width: '212px', 
//                   height: 'auto',
//                   marginTop: '5px',
//                   paddingLeft: '0px'
//                 }} 
//               />
//             </Link>
//           </div>

//           {/* 3. FIX: Yeh Hamburger Button hai jo mobile screen par menu show karega */}
//           <button 
//             className="navbar-toggler" 
//             type="button" 
//             data-bs-toggle="offcanvas" 
//             data-bs-target="#offcanvas-nav" 
//             aria-controls="offcanvas-nav" 
//             aria-label="Toggle navigation"
//           >
//             <span className="navbar-toggler-icon"></span>
//           </button>

//           {/* Offcanvas Main Menu */}
//           <div id="offcanvas-nav" className="navbar-collapse offcanvas offcanvas-nav offcanvas-start" tabIndex="-1">
            
//             {/* 4. FIX: Mobile view mein menu ke andar Close (X) button aur header */}
//             <div className="offcanvas-header d-lg-none">
//               <h5 className="offcanvas-title">Menu</h5>
//               <button type="button" className="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
//             </div>

//             <div className="offcanvas-body ms-lg-auto d-flex flex-column h-100">
//               <ul className="navbar-nav">
//                 <li className="nav-item"><Link to="/" className="nav-link">Home</Link></li>
//                 <li className="nav-item"><Link to="/about" className="nav-link">About Us</Link></li>
//                 <li className="nav-item"><Link to="/gallery" className="nav-link">Gallery</Link></li>
//                 <li className="nav-item"><Link to="/contact" className="nav-link">Contact Us</Link></li>
//                 <li className="nav-item d-flex align-items-center ms-lg-4 mt-3 mt-lg-0">
//                   <button 
//                     className="btn-modern-appointment w-100 w-lg-auto" 
//                     onClick={() => {
//                       formRef.current.scrollIntoView({ behavior: "smooth" });
//                       // Mobile par click karne ke baad menu close ho jaye
//                       const offcanvasEl = document.getElementById('offcanvas-nav');
//                       const bootstrap = window.bootstrap;
//                       if (bootstrap && offcanvasEl) {
//                         const instance = bootstrap.Offcanvas.getInstance(offcanvasEl);
//                         if (instance) instance.hide();
//                       }
//                     }}
//                   >
//                     Book Appointment
//                   </button>
//                 </li>
//               </ul>
//             </div>
//           </div>

//         </div>
//       </nav>
//     </>
//   );
// };

// export default Navbar;