import React from 'react';

const Topbar = () => {
  const contactItems = [
    {
      href: 'tel:+923104443936',
      icon: 'uil-phone-volume',
      text: '+92 310 4443936',
    },
    {
      href: 'mailto:rababzahra425@gmail.com',
      icon: 'uil-envelope',
      text: 'rababzahra425@gmail.com',
    },
  ];

  const socialLinks = [
    {
      href: 'https://www.facebook.com/',
      icon: 'uil-facebook-f', // Added -f for better icon support
    },
    {
      href: 'https://www.instagram.com/',
      icon: 'uil-instagram',
    },
  ];

  return (
    // Changed 'py-2' to 'py-1' to reduce height
    <section className="bg-color d-none d-md-block py-1"> 
      <div className="container text-white">
        <div className="row align-items-center">
          {/* Opening Times */}
          <div className="col-auto d-none d-xl-flex">
            <p className="m-0 text-white lato small">
              Opening Time: Monday To Saturday - (10am to 2pm & 5pm to 8pm)
            </p>
          </div>

          {/* Contact and Socials pushed to the right */}
          <div className="col d-flex justify-content-end align-items-center">
            {contactItems.map(({ href, icon, text }, index) => (
              <div key={index} className="d-flex align-items-center ms-4">
                <i className={`${icon} me-2`} style={{ fontSize: '16px' }} />
                <a href={href} className="link-white hover lato small text-decoration-none text-white">
                  {text}
                </a>
              </div>
            ))}

            {/* Social Links Fix */}
            <div className="d-flex align-items-center ms-4">
              {socialLinks.map(({ href, icon }, index) => (
                <a
                  key={index}
                  href={href}
                  className="text-white hover ms-3"
                  target="_blank"
                  rel="noreferrer"
                >
                  <i className={icon} style={{ fontSize: '18px' }} />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Topbar;