import React from 'react';

const Footer = () => {
  return (
    <footer className="pt-5 pb-3 text-white" style={{ 
      background: 'linear-gradient(135deg, #001f3f 0%, #003366 100%)',
      borderTop: '4px solid #00aaff'
    }}>
      <div className="container">
        <div className="row g-4 mb-5">
          <div className="col-lg-4 col-md-12">
            <div className="d-flex align-items-center mb-3">
              <i className="bi bi-shield-plus fs-1 me-2" style={{ color: '#00aaff' }}></i>
              <h3 className="fw-bold mb-0" style={{ letterSpacing: '1px' }}><span>DENTISTREE</span></h3>
            </div>
            <p className="opacity-75 pe-lg-5" style={{ fontSize: '0.95rem', lineHeight: '1.8' }}>
              At Dentistree, we combine advanced technology with a patient-centered approach to provide the highest quality dental care. Our mission is to help you achieve a healthy, confident smile that lasts a lifetime.
            </p>
            <div className="mt-4">
              <h6 className="fw-bold mb-3 text-uppercase small" style={{ letterSpacing: '2px', color: '#00aaff' }}>Follow Our Journey</h6>
              <div className="d-flex gap-3">
                <a href="#" className="social-link"><i className="bi bi-facebook"></i></a>
                <a href="#" className="social-link"><i className="bi bi-instagram"></i></a>
                <a href="#" className="social-link"><i className="bi bi-twitter-x"></i></a>
                <a href="#" className="social-link"><i className="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>

          {/* Column 2: Services */}
          <div className="col-lg-2 col-md-4">
            <h5 className="fw-bold mb-4 border-bottom border-primary border-2 pb-2 d-inline-block">Services</h5>
            <ul className="list-unstyled footer-links">
              <li><a href="#">Dental Implants</a></li>
              <li><a href="#">Root Canal</a></li>
              <li><a href="#">Teeth Whitening</a></li>
              <li><a href="#">Orthodontics</a></li>
              <li><a href="#">Pediatric Care</a></li>
              <li><a href="#">Cosmetic Dentistry</a></li>
            </ul>
          </div>

          {/* Column 3: Quick Links */}
          <div className="col-lg-2 col-md-4">
            <h5 className="fw-bold mb-4 border-bottom border-primary border-2 pb-2 d-inline-block">Quick Links</h5>
            <ul className="list-unstyled footer-links">
              <li><a href="#">About Dentetree</a></li>
              <li><a href="#">Our Specialists</a></li>
              <li><a href="#">Latest Gallery</a></li>
              <li><a href="#">Book Now</a></li>
              <li><a href="#">Privacy Policy</a></li>
            </ul>
          </div>

          {/* Column 4: Contact Info */}
          <div className="col-lg-4 col-md-4">
            <h5 className="fw-bold mb-4 border-bottom border-primary border-2 pb-2 d-inline-block">Contact Us</h5>
            <div className="d-flex mb-3 align-items-start">
              <div className="contact-icon-box me-3">
                <i className="bi bi-geo-alt-fill"></i>
              </div>
              <p className="mb-0 opacity-75" style={{ fontSize: '0.9rem' }}>
                Main Market Farid Town, Sahiwal, Pakistan<br />Sahiwal, Punjab, Pakistan
              </p>
            </div>
            <div className="d-flex mb-3 align-items-center">
              <div className="contact-icon-box me-3">
                <i className="bi bi-envelope-fill"></i>
              </div>
              <p className="mb-0 opacity-75" style={{ fontSize: '0.9rem' }}>dentistree@gmail.com</p>
            </div>
            <div className="d-flex align-items-center">
              <div className="contact-icon-box me-3">
                <i className="bi bi-telephone-fill"></i>
              </div>
              <p className="mb-0 opacity-75" style={{ fontSize: '0.9rem' }}>+92 321 7450249</p>
            </div>
          </div>
        </div>

        <hr className="opacity-10" />

        <div className="row mt-4 align-items-center">
          <div className="col-md-6 text-center text-md-start">
            <p className="small opacity-50 mb-0">
              © 2026 Dentetree Dental Care. All rights reserved.
            </p>
          </div>
          <div className="col-md-6 text-center text-md-end mt-2 mt-md-0">
            <p className="small opacity-50 mb-0">
              Designed for Excellence in Oral Health.
            </p>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .footer-links li {
          margin-bottom: 12px;
        }
        .footer-links a {
          color: rgba(255,255,255,0.7);
          text-decoration: none;
          font-size: 0.9rem;
          transition: 0.3s all ease;
        }
        .footer-links a:hover {
          color: #00aaff;
          padding-left: 8px;
        }
        .social-link {
          width: 38px;
          height: 38px;
          background: rgba(255,255,255,0.1);
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          color: white;
          text-decoration: none;
          transition: 0.3s;
        }
        .social-link:hover {
          background: #00aaff;
          color: white;
          transform: translateY(-3px);
        }
        .contact-icon-box {
          color: #00aaff;
          font-size: 1.1rem;
        }
      `}} />
    </footer>
  );
};

export default Footer;