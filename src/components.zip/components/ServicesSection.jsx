import React from 'react';

// Asset Imports
import implants from '../assets/img/implants.jpg';
import root from '../assets/img/root.jpg';
import cavityfilling from '../assets/img/cavityfilling.jpg';
import orthodic from '../assets/img/orthodic.jpg';
import teethwhite from '../assets/img/teethwhite.webp';
import wisdom from '../assets/img/wisdom.jpg';
import crowns from '../assets/img/crowns.jpg'; 
import pediatric from '../assets/img/pediatric.webp';

const ServicesSection = () => {
  const services = [
    {
      id: 1,
      title: "Dental Implants",
      description: "A permanent and natural-looking solution to replace missing teeth and restore your beautiful smile.",
      image: implants 
    },
    {
      id: 2,
      title: "Root Canal Treatment",
      description: "A precise procedure to save infected teeth and eliminate pain while preserving your natural tooth structure.",
      image: root
    },
    {
      id: 3,
      title: "Cavity Filling",
      description: "High-quality, tooth-colored fillings used to repair decay and protect your teeth from further damage.",
      image: cavityfilling
    },
    {
      id: 4,
      title: "Orthodontics",
      description: "Expert alignment services, including braces and clear aligners, to give you perfectly straight teeth.",
      image: orthodic
    },
    {
      id: 5,
      title: "Teeth Whitening",
      description: "Professional whitening treatments to remove stains and brighten your smile by several shades instantly.",
      image: teethwhite
    },
    {
      id: 6,
      title: "Wisdom Tooth Surgery",
      description: "Safe and comfortable surgical removal of impacted wisdom teeth to prevent crowding and future pain.",
      image: wisdom
    },
    {
      id: 7,
      title: "Crown & Bridges",
      description: "Custom-made dental caps and bridges designed to strengthen damaged teeth and fill gaps seamlessly.",
      image: crowns
    },
    {
      id: 8,
      title: "Pediatric Dentistry",
      description: "Specialized and friendly dental care for children, ensuring a positive experience for our youngest patients.",
      image: pediatric
    }
  ];

  return (
    <section className="services-section-padding" style={{ backgroundColor: '#f8f9fa' }}>
      <div className="container text-center">
        {/* HEADING: Matches the 'About' section style exactly */}
        <h2 className="services-main-title">
          Best Dental Services In Your Location
        </h2>

        {/* Grid layout for service cards */}
        <div className="row g-4 justify-content-center">
          {services.map((service) => (
            <div className="col-12 col-md-6 col-lg-3" key={service.id}>
              <div 
                className="card border-0 shadow-sm h-100 overflow-hidden rounded-4 service-card-hover"
                style={{ transition: 'transform 0.3s ease' }}
                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-8px)'}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateY(0)'}
              >
                <img 
                  src={service.image} 
                  className="card-img-top" 
                  alt={service.title}
                  style={{ height: '200px', objectFit: 'cover' }}
                />
                
                <div className="card-body p-4 text-start">
                  <h5 className="service-card-title">
                    {service.title}
                  </h5>
                  <p className="service-card-text">
                    {service.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;


// import React from 'react';

// // Icons imports remain the same
// import expertCare from '../assets/img/icons/expert-care.webp';
// import advancedTech from '../assets/img/icons/advanced-technologys.jpeg';
// import patientCentered from '../assets/img/icons/patient-centered.webp';
// import trustedDentistry from '../assets/img/icons/trusted-dentistry.webp';
// import modernFacilities from '../assets/img/icons/modern-facilities.webp';
// import skilledTeam from '../assets/img/icons/skilled-team.webp';

// const WhyChoose = () => {
//   const features = [
//     { title: "Expert Care", icon: expertCare, desc: "Our experienced specialists provide professional dental treatments with a gentle touch and personalized attention." },
//     { title: "Advanced Technology", icon: advancedTech, desc: "We utilize state-of-the-art dental equipment and digital imaging to ensure precise and painless procedures." },
//     { title: "Patient-Centered", icon: patientCentered, desc: "Your comfort is our top priority. We design every treatment plan around your unique needs and oral health goals." },
//     { title: "Trusted Dentistry", icon: trustedDentistry, desc: "With years of proven excellence, we are proud to be the most trusted name in dental care within the community." },
//     { title: "Modern Facilities", icon: modernFacilities, desc: "Experience world-class dental services in a clean, modern, and fully sterilized environment built for your relaxation." },
//     { title: "Skilled Team", icon: skilledTeam, desc: "Our team consists of highly qualified dental experts dedicated to maintaining your beautiful and healthy smile." }
//   ];

//   return (
//     <section className="py-10 bg-white mt-5 pt-5">
//       <div className="container text-center">
        
        

//         {/* Heading style remains consistent with the Hospital section */}
//         <h2 
//           className="services-main-title mb-5" 
//           style={{ 
//             color: '#003366', 
//             fontSize: '3rem', 
//             lineHeight: '1.2',
//             fontWeight: '800'
//           }}
//         >
//           Dental Clinic for Your <br /> Dental Needs
//         </h2>

//         <div className="row g-4">
//           {features.map((f, index) => (
//             <div key={index} className="col-md-6 col-lg-4">
//               <div 
//                 className="why-choose-card p-5 rounded-4 h-100 shadow-sm border-0"
//                 style={{ 
//                   backgroundColor: '#f8f9fa', 
//                   color: '#003366',
//                   transition: '0.4s ease-in-out',
//                   cursor: 'pointer'
//                 }}
//               >
//                 <div className="mb-4 icon-container">
//                   <img 
//                     src={f.icon} 
//                     alt={f.title} 
//                     className="feature-icon"
//                     style={{ width: '60px', height: '60px', transition: '0.4s' }} 
//                   />
//                 </div>
//                 <h4 className="fw-bold mb-3" style={{ fontFamily: 'Merriweather, serif' }}>{f.title}</h4>
//                 <p className="text-muted feature-desc" style={{ fontSize: '0.95rem', lineHeight: '1.6' }}>
//                   {f.desc}
//                 </p>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>

//       <style dangerouslySetInnerHTML={{ __html: `
//         .why-choose-card:hover {
//           background-color: #003366 !important;
//           transform: translateY(-10px);
//           box-shadow: 0 1rem 3rem rgba(0,0,0,.15) !important;
//         }
        
//         .why-choose-card:hover h4,
//         .why-choose-card:hover .feature-desc {
//           color: #ffffff !important;
//         }

//         .why-choose-card:hover .feature-icon {
//           filter: brightness(0) invert(1);
//         }
//       `}} />
//     </section>
//   );
// };

// export default WhyChoose;